from django.shortcuts import render
from nltkapp.models import Document, Corpus
import logging

# Create your views here.
logger = logging.getLogger('nltksite3.nltkapp')

def index(request):
	logger.debug("index requested.")
	corpora = Corpus.objects.all()
	context = {'corpora': corpora}
	return render(request, 'nltkapp/index.html', context)
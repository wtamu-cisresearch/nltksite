# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import nltkapp.models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Corpus',
            fields=[
                ('id', models.AutoField(primary_key=True, auto_created=True, verbose_name='ID', serialize=False)),
                ('name', models.CharField(max_length=30)),
                ('internal_nltk_name', models.CharField(help_text='Leave blank unless you are adding an NLTK built-in corpus, in which case, supply the name of the corpus.', blank=True, max_length=15, verbose_name='Internal NLTK Corpus name (optional)')),
                ('internal_nltk_filter', models.CharField(help_text='Used with Internal NLTK Corpus name if you want to filter the NLTK Corpus even further. Leave blank for default.', blank=True, max_length=30, verbose_name='Internal NLTK Corpus filter (optional)')),
            ],
            options={
                'verbose_name_plural': 'Corpora',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Document',
            fields=[
                ('id', models.AutoField(primary_key=True, auto_created=True, verbose_name='ID', serialize=False)),
                ('file', models.FileField(upload_to=nltkapp.models.document_file_location)),
                ('corpus', models.ForeignKey(to='nltkapp.Corpus')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]

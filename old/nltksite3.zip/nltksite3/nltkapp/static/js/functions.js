/**
 * Created by Administrator on 4/11/2015.
 */
function displayDateInTitle() {
    var date = new Date()
    document.title = date;
    document.getElementById("div1").innerHTML = date;
    setTimeout("displayDateInTitle()", 200);
}
function getDiv1() {
    console.log(document.getElementById("div1").innerHTML);
}

// Kareem Addition - if you call ajaxHelloWorld it will:
// 1) Invoke the method sayhello inside ajax.py
// 2) When sayhello is complete, return the result to mycallback
// This setup demonstrates ajax with Dajaxice in Django

function mycallback(data) {
	alert(data.message);
}
	
function ajaxHelloWorld() {
	Dajaxice.nltkapp.sayhello(mycallback);
}
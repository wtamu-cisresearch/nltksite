from django.conf.urls.defaults import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

# enable dajaxice
from dajaxice.core import dajaxice_autodiscover
from django.conf import settings
dajaxice_autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'nltksite.views.home', name='home'),
    # url(r'^nltksite/', include('nltksite.foo.urls')),
    url(r'^polls/', include('polls.urls')),
    url(r'^nltkapp/', include('nltkapp.urls')),
    url(r'^nltkmusa/', include('nltkmusa.urls')),
    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),

    # Uncomment the next line to enable dajaxice:
    url(r'^%s/' % settings.DAJAXICE_MEDIA_PREFIX, include('dajaxice.urls')),
)

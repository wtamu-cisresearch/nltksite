from django.db import models
from django.db.models.signals import pre_delete
from django.dispatch import receiver
from django.conf import settings
import logging
logger = logging.getLogger('nltksite.nltkapp')

# Create your models here.
class UploadedFile(models.Model):
    uploaded_file = models.FileField(upload_to='documents/')
    
    def __unicode__(self):
        return self.uploaded_file.name


# pre-delete signal callback
# This function is called everytime an instance of UploadedFile is slated to be deleted
@receiver(pre_delete, sender=UploadedFile)
def pre_delete_handler(sender, instance, **kwargs):
    try:
        logger.debug('Deleting %s' % (instance.uploaded_file.name))
        instance.uploaded_file.delete()
    except:
        logger.error('Error unlinking file: %s' % (sys.exc_info()[1]))

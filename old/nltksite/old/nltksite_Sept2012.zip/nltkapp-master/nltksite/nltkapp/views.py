# Create your views here.
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.shortcuts import render_to_response
from django.template import RequestContext
from nltkapp.models import UploadedFile
from nltkapp.forms import UploadFileForm
import logging

logger = logging.getLogger('nltksite.nltkapp')

def index(request):
    # Session will expire when user closes browser
    request.session.set_expiry(0)
    request.session['special_cookie'] = True
    # If user is uploading a file - manage it here
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            new_file = UploadedFile(uploaded_file = request.FILES['uploaded_file'])
            new_file.save()
            request.session['selected_file_id'] = new_file.id
            request.session['selected_file_name'] = new_file.uploaded_file.name
            return HttpResponseRedirect(reverse('nltkapp.views.index'))
    else:
        form = UploadFileForm()

    response_args = {'form': form, 'file_list': UploadedFile.objects.all()}
    if 'selected_file_id' in request.session:
        response_args['selected_file_id'] = request.session['selected_file_id']
        del(request.session['selected_file_id'])
    if 'selected_file_name' in request.session:
        response_args['selected_file_name'] = request.session['selected_file_name']
        del(request.session['selected_file_name'])

    return render_to_response('nltkapp/index.html', response_args, context_instance=RequestContext(request));

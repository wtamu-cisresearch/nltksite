import sys
sys.stdout = sys.stderr
from django.conf import settings
from django.contrib.sessions.backends.db import SessionStore
from django.utils import simplejson
from dajaxice.decorators import dajaxice_register
import nltk
from nltk.corpus import * 
from nltk.collocations import *
from nltk.book import *
from nltkapp.models import UploadedFile
import string
import re
import logging
logger = logging.getLogger('nltksite.nltkapp')

excludeWords = ['will', 'the', 'i', 'to', 'a', 'and', 'of', 'for', 'in', 'as', 'at', 'our', 'or', 'my', 'is', 'an', 'that', 'were', 'it', '\'s', 'am', 'on', 'with', 'new', 'have', 'but', 'also', 'we', 'west', 'texas', 'a&m', 'are', 'upon', 'cis', 'they', 'would', 'was', 'if', 'there', 'them', 'within','using', 'be', 'their', 'no', 'not', 'only', 'who', 'this', 'changed']

@dajaxice_register
def wordfreq(request, file_id, ngram, score):
    logger.debug("Going to do n-gram analysis on " + file_id + " with scoring method " + score)

    if "mobydick" in file_id:
        words = gutenberg.words('melville-moby_dick.txt')
    elif "sense" in file_id:
        words = gutenberg.words('austen-sense.txt')
    elif "genesis" in file_id:
        words = genesis.words()
    elif "inaugural" in file_id:
        words = inaugural.words()
    elif "chat" in file_id:
        words = nps_chat.words()
    elif "monty" in file_id:
        words = webtext.words('grail.txt')
    elif "wallstreet" in file_id:
        words = brown.words('ca28')
    elif "personals" in file_id:
        words = webtext.words('singles.txt')
    elif "chesterton" in file_id:
        words = gutenberg.words('chesterton-thursday.txt')
    else:
        file_model = UploadedFile.objects.get(id=file_id)
        file_path = settings.MEDIA_ROOT + "/"
        newcorpus = PlaintextCorpusReader(file_path, file_model.uploaded_file.name)
        words = newcorpus.words()
    
    if ngram == "1":
        return onegram_collocation(words)
    elif ngram == "2":
        first_word_list, fdist = bigram_collocation(words, score)
    elif ngram == "3":
        first_word_list, fdist = trigram_collocation(words, score)
    else:
        logger.debug("Invalid ngram value specified. " + ngram)
    
    word_list = []
    for b in first_word_list:
        for sample in fdist:
            if b == sample:
                innerlist = [' '.join(sample).decode('utf8', 'ignore'), fdist[sample]]
                break
        word_list.append(innerlist)
    
    return simplejson.dumps({'list':word_list})

def open_file_from_id(file_id):
    file_model = UploadedFile.objects.get(id=file_id)
    file_path = settings.MEDIA_ROOT + "/" +  file_model.uploaded_file.name
    f = open(file_path).read().decode('utf8', 'ignore')
    return f

def onegram_collocation(words):
    fdist = nltk.FreqDist(words)
    word_list = []
    for sample in fdist:
        if not sample in string.punctuation:
            word_list.append([sample.decode('utf8', 'ignore'), fdist[sample]])
        
    return simplejson.dumps({'list':word_list})

def bigram_collocation(words, score):
    ignored_words = stopwords.words('english')
    bigrams = nltk.bigrams(words)
    fdist = nltk.FreqDist(bigrams)
    bigram_measures = nltk.collocations.BigramAssocMeasures()
    finder = BigramCollocationFinder.from_words(words)
    
    # Only select bigrams that appear at least 3 times
    finder.apply_freq_filter(3)
    finder.apply_word_filter(lambda w: len(w) < 3 or w.lower() in ignored_words)

    # return the 10 bigrams with the highest PMI
    method = bigram_measures.pmi
    if "student_t" in score:
        method = bigram_measures.student_t
    elif "chi_sq" in score:
        method = bigram_measures.chi_sq
    elif "pmi" in score:
        method = bigram_measures.pmi
    elif "likelihood_ratio" in score:
        method = bigram_measures.likelihood_ratio
    elif "poisson_stirling" in score:
        method = bigram_measures.poisson_stirling
    elif "jaccard" in score:
        method = bigram_measures.jaccard

    word_list = finder.nbest(method, 100)
    return [word_list, fdist] 

def trigram_collocation(words, score):
    ignored_words = stopwords.words('english')
    trigrams = nltk.trigrams(words)
    fdist = nltk.FreqDist(trigrams)
    trigram_measures = nltk.collocations.TrigramAssocMeasures()
    finder = TrigramCollocationFinder.from_words(words)
    finder.apply_freq_filter(3)
    finder.apply_word_filter(lambda w: len(w) < 3 or w.lower() in ignored_words)
    
    method = trigram_measures.pmi
    if "student_t" in score:
        method = trigram_measures.student_t
    elif "chi_sq" in score:
        method = trigram_measures.chi_sq
    elif "pmi" in score:
        method = trigram_measures.pmi
    elif "likelihood_ratio" in score:
        method = trigram_measures.likelihood_ratio
    elif "poisson_stirling" in score:
        method = trigram_measures.poisson_stirling
    elif "jaccard" in score:
        method = trigram_measures.jaccard
    
    word_list = finder.nbest(method, 100)
    return [word_list, fdist]

@dajaxice_register
def get_sentences(request, file_id, word):
    if "mobydick" in file_id:
        sents = gutenberg.sents('melville-moby_dick.txt')
    elif "sense" in file_id:
        sents = gutenberg.sents('austen-sense.txt')
    elif "genesis" in file_id:
        sents = genesis.sents()
    elif "inaugural" in file_id:
        sents = inaugural.sents()
    elif "chat" in file_id:
        sents = nps_chat.sents()
    elif "monty" in file_id:
        sents = webtext.sents('grail.txt')
    elif "wallstreet" in file_id:
        sents = brown.sents('ca28')
    elif "personals" in file_id:
        sents = webtext.sents('singles.txt')
    elif "chesterton" in file_id:
        sents = gutenberg.sents('chesterton-thursday.txt')
    else:
        file_model = UploadedFile.objects.get(id=file_id)
        file_path = settings.MEDIA_ROOT + "/"
        newcorpus = PlaintextCorpusReader(file_path, file_model.uploaded_file.name)
        sents = newcorpus.sents()
    
    results = []
    for sentence in sents:
        combined = ' '.join(sentence).decode('utf8', 'ignore')
        if word in combined: results.append(combined)
    
    return simplejson.dumps({'word': word, 'sentences':results})

@dajaxice_register
def regex_search(request, file_id, regex_pattern):
    if "mobydick" in file_id:
        raw = gutenberg.raw('melville-moby_dick.txt')
    elif "sense" in file_id:
        raw = gutenberg.raw('austen-sense.txt')
    elif "genesis" in file_id:
        raw = genesis.raw()
    elif "inaugural" in file_id:
        raw = inaugural.raw()
    elif "chat" in file_id:
        raw = nps_chat.raw()
    elif "monty" in file_id:
        raw = webtext.raw('grail.txt')
    elif "wallstreet" in file_id:
        raw = brown.raw('ca28')
    elif "personals" in file_id:
        raw = webtext.raw('singles.txt')
    elif "chesterton" in file_id:
        raw = gutenberg.raw('chesterton-thursday.txt')
    else:
        file_model = UploadedFile.objects.get(id=file_id)
        file_path = settings.MEDIA_ROOT + "/"
        newcorpus = PlaintextCorpusReader(file_path, file_model.uploaded_file.name)
        raw = newcorpus.raw()

    #match = re.search(regex_pattern, f)
    matches = re.findall(regex_pattern, raw)
    return simplejson.dumps({'result':list(set(matches))})

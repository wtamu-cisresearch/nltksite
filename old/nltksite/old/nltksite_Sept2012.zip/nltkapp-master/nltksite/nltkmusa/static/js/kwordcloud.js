var $c = $("#canvas");
var wordfreq = WordFreq({worker: '../static/js/wordfreq.worker.js'});
var weightFactor = 0;
var gridSize = 8;
var text = '';
var list = [];

function resetCanvasSize() {
    var width = document.body.offsetWidth,
    height = document.body.offsetHeight;
    
    $c.attr(
    {
        height: height,
        width: width
    }       
    ).css({
        width: width.toString(10) + 'px',
        height: height.toString(10) + 'px',
        top: '50%',
        left: '50%',
        marginLeft: '-' + (width/2).toString(10) + 'px',
        marginTop: '-' + (height/2).toString(10) + 'px'
    });
}

function WordCloudDemo() {
    var oRequest = new XMLHttpRequest();
    var sURL = "/static/googleeula.txt";

    oRequest.open("GET", sURL, false);
    oRequest.setRequestHeader("User-Agent",navigator.userAgent);
    oRequest.send(null)
    text = oRequest.responseText
    if (oRequest.status!=200) alert("Error executing XMLHttpRequest call!");
    //resetCanvasSize()     
    wordfreq.empty()
    wordfreq.processText(
            text, 
            function () {
                alert("text callback");
                wordfreq.getSortedList(
                    function (l) {
                        list = l;
                        wordfreq.analyizeVolume(
                            function (volume) {
                                weightFactor = Math.sqrt(document.body.offsetHeight * document.body.offsetWidth / volume) * 1;
                                gridSize = 8;
                                alert("analyize Volume callback");
                                $("#canvas").wordCloud({
                                    wordList: list
                                });
                            }
                        )
                    }
                )
            }
    );
}


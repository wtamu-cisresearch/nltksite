from cStringIO import StringIO
import sys
sys.stdout = nltkapp_stdout = StringIO()

from django.contrib.sessions.backends.db import SessionStore
from django.utils import simplejson
from dajaxice.decorators import dajaxice_register
import nltk
from nltk.book import *
from nltkmusa.models import UploadedFile

@dajaxice_register
def processrequest(request, text):
    global nltkapp_stdout
    nltkapp_dbg = StringIO()
    # Restore locals
    if 'nltk_command' in request.session:
        print >>nltkapp_dbg, "Previous NLTK Command:", request.session['nltk_command']
    else:
        print >>nltkapp_dbg, "Previous NLTK Command: (None)"

    request.session['nltk_command'] = text
    
    try:
        #print >>nltkapp_dbg, "Previous NLTK Context:", request.session['nltk_context'];
        for nltkapp_item in request.session['nltk_context'].items():
            vars()[nltkapp_item[0]] = nltkapp_item[1]
    except:
        print >>nltkapp_dbg, "Error importing NLTK Context:", sys.exc_info()[1]
    # Tokenize the uploaded files and make them accessable
    nltkapp_u = []
    for nltkapp_idx in UploadedFile.objects.all():
        nltkapp_u.append(nltkapp_idx)
       # if (len(nltkapp_idx.raw) == 0):
       #     nltkapp_idx.read()
        print >>nltkapp_dbg, "Uploaded File: ", nltkapp_idx.id, " ", nltkapp_idx.uploaded_file.name

    try:
        exec(text)
        nltkapp_context = locals()
        nltkapp_newcontext = dict()
        print >>nltkapp_dbg, "Current NLTK Context:"
        for nltkapp_item in nltkapp_context.items():
            if (not nltkapp_item[0].startswith("nltkapp") and not nltkapp_item[0].startswith("__")
                and not nltkapp_item[0].startswith("text") and not nltkapp_item[0].startswith("request")):
                #print >>nltkapp_dbg, nltkapp_item[0], ":", nltkapp_item[1]
                nltkapp_newcontext[nltkapp_item[0]] = nltkapp_item[1]
        request.session['nltk_context'] = nltkapp_newcontext
    except:
        print "Error:", sys.exc_info()[1]

    if (len(nltkapp_stdout.getvalue()) == 0):
        print "(None)"
   # print >> nltkapp_dbg, request
    print "\n\nDebug:\n", nltkapp_dbg.getvalue()
    nltkapp_dbg.close()

    nltkapp_output = nltkapp_stdout.getvalue()
    nltkapp_output = nltkapp_output.replace("\n", "<br>")
    nltkapp_stdout.truncate(0)
    return simplejson.dumps({'message':nltkapp_output})


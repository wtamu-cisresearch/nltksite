from nltkmusa.models import UploadedFile
from django.contrib import admin

admin.site.register(UploadedFile)

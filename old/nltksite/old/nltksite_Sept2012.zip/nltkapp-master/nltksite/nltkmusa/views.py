# Create your views here.
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.shortcuts import render_to_response
from django.template import RequestContext
from nltkmusa.models import UploadedFile
from nltkmusa.forms import UploadFileForm
import logging

logger = logging.getLogger('nltksite.nltkmusa')

def index(request):
    # Session will expire when user closes browser
    # logger.debug('Testing');
    request.session.set_expiry(0);
    request.session['special_cookie'] = True
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            # Do stuff here
            request.session['message'] = "File Uploaded: ", request.FILES['uploaded_file'].name
            newfile = UploadedFile(uploaded_file = request.FILES['uploaded_file'])
            newfile.save()
            return HttpResponseRedirect(reverse('nltkmusa.views.index'))
    else:
        form = UploadFileForm()

    response_args = {'form': form}
    if 'message' in request.session:
        response_args['message'] = request.session['message']
        del(request.session['message'])
    
    return render_to_response('nltkmusa/index.html', response_args, context_instance=RequestContext(request));

from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('nltkmusa.views',
    url(r'^$', 'index', name='index'),
)

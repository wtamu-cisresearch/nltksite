from django.db import models
from django.db.models.signals import pre_delete
from django.dispatch import receiver
from django.conf import settings
try:
    import cPickle as pickle
except:
    import pickle
import base64
import nltk
import sys
import logging
logger = logging.getLogger('nltksite.nltkmusa')

class SerializedDataField(models.TextField):
    """Because Django for some reason feels its needed to repeatedly call
    to_python even after it's been converted this does not support strings."""
    __metaclass__ = models.SubfieldBase

    def to_python(self, value):
        if value is None: return
        if value =='': return ''
        if not isinstance(value, basestring): return value
        value = pickle.loads(base64.b64decode(value))
        return value

    def get_db_prep_save(self, value):
        if value is None: return
        if value == '': return ''
        return base64.b64encode(pickle.dumps(value))

# Create your models here.
class UploadedFile(models.Model):
    uploaded_file = models.FileField(upload_to='documentsmusa/')
    raw = models.TextField()
    tokens = SerializedDataField(default="")
    def read(self):
        self.raw = self.uploaded_file.read()
        self.tokens = nltk.word_tokenize(self.raw)
        self.save()
        return
    def __unicode__(self):
        return self.uploaded_file.name


# pre-delete signal callback
# This function is called everytime an instance of UploadedFile is slated to be deleted
@receiver(pre_delete, sender=UploadedFile)
def pre_delete_handler(sender, instance, **kwargs):
    try:
        logger.debug('Deleting %s' % (instance.uploaded_file.name))
        instance.uploaded_file.delete()
    except:
        logger.error('Error unlinking file: %s' % (sys.exc_info()[1]))
